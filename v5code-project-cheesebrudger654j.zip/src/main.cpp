/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\s121850                                          */
/*    Created:      Tue Oct 22 2024                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Inertial             inertial      7               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
using namespace vex;
competition Competiton;
bool running = false;
bool sitting = false;
bool mogo2 = false;
void fullintake(){
  running = !running;
  if(running){
    sitting = false;
    intake.setVelocity(70,percent);
    convey.setVelocity(70,percent);
    intake.spin(forward);
    convey.spin(reverse);
  }
  else{
    sitting = false;
    intake.stop();
    convey.stop();
  }
  
}
void reverse2(){
  sitting = !sitting;
  if(sitting){
    running = false;
    intake.setVelocity(70,percent);
    convey.setVelocity(70,percent);
    intake.spin(reverse);
    convey.spin(forward);
  }
  else{
    running = false;
    intake.stop();
    convey.stop();
  }
}
  
  void mogo3(){
  mogo2 = !mogo2;
  if (mogo2){
  mogo.set(false);
  }
  else{
    mogo.set(true);
  }
  
}
void auton(){
  mogo.set(false);
  intake.setVelocity(70, percent);
  convey.setVelocity(100, percent);
  Drivetrain.setDriveVelocity(40, percent);
  convey.spin(reverse);
  wait(1, seconds);
  convey.spin(forward);
  wait(0.4,seconds);
  convey.stop();
  Drivetrain.driveFor(forward, 25, inches);
  Drivetrain.turnFor(right, 160, degrees);
  Drivetrain.driveFor(reverse,38,inches);
  mogo.set(true);
  convey.spin(reverse);
  intake.spin(forward);
  Drivetrain.turnFor(left, 160,degrees);
  Drivetrain.driveFor(forward, 37, inches);
  Drivetrain.turnFor(left,160, degrees);
  Drivetrain.driveFor(forward,37,inches);
  Drivetrain.turnFor(left,160,degrees);
  Drivetrain.driveFor(forward,50,inches);
  Drivetrain.driveFor(reverse,30,inches);
  Drivetrain.turnFor(right,80,degrees);
  Drivetrain.driveFor(forward,16, inches);
  wait(1,seconds);
  Drivetrain.driveFor(reverse,16,inches);
  Drivetrain.turnFor(right,222,degrees);
  Drivetrain.driveFor(forward,48,inches);
  wait(1,seconds);
  Drivetrain.turnFor(right,45, degrees);
  Drivetrain.driveFor(reverse,82,inches);
  mogo.set(false);
  wait(1, seconds);
  Drivetrain.driveFor(forward,20,inches);
  Drivetrain.turnFor(right,146,degrees);
  Drivetrain.driveFor(forward,100,inches);
  mogo.set(false);
  wait(1,seconds);
  Drivetrain.turnFor(right, 170,degrees);
  Drivetrain.driveFor(forward, 50, inches);
  Drivetrain.turnFor(right,170, degrees);
  Drivetrain.driveFor(forward,50,inches);
  Drivetrain.turnFor(right,170,degrees);
  Drivetrain.driveFor(forward,100,inches);
  Drivetrain.driveFor(reverse,30,inches);
  Drivetrain.turnFor(left,170,degrees);
  Drivetrain.driveFor(forward, 10, inches);
  Drivetrain.turnFor(left,170,degrees);
  Drivetrain.driveFor(forward,100,inches);
  Drivetrain.stop();
  wait(1,seconds);
  Drivetrain.driveFor(reverse, 100, inches);
  mogo.set(true);
  Drivetrain.driveFor(forward,10,inches);
  }

int main() {
  mogo.set(false);
  Controller1.ButtonR1.pressed(fullintake);
  Controller1.ButtonR2.pressed(reverse2);
  Controller1.ButtonL1.pressed(mogo3);
  Competiton.autonomous(auton);
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
}
