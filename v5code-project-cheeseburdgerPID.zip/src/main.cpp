/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <iostream>
#include <sstream>

using namespace vex;
using namespace std;
// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/
//Variables 
bool resetDriveSensors = false;
bool pidEnable = true;

//Auton settings
int desiredValue = 200;
int desiredTurnValue = 0;
//settings
double kP = 0.0;
double kI = 0.0;
double kD = 0.0;

double turnkP = 0.0;
double turnkI = 0.0;
double turnkD = 0.0;
//lateral
int error; // sensor value - desired value: positional value -> speed -> acceleration.
int prevError = 0 ; // Position 20 miliseconds ago
int derivative; // error - prevError : speed
int totalError =0 ;// total error = total error + error
//turning
int turnError; // sensor value - desired value: positional value -> speed -> acceleration.
int turnPrevError = 0 ; // Position 20 miliseconds ago
int turnDerivative; // error - prevError : speed
int turnTotalError =0 ;// total error = total error + error

int drivePID(){
  while(pidEnable){
    
    if(resetDriveSensors){
      resetDriveSensors = false;
      LeftDriveSmart.setPosition(0, degrees);
      RightDriveSmart.setPosition(0, degrees);

    }
    int leftMotorPosition = LeftDriveSmart.position(degrees);
    int rightMotorPosition = RightDriveSmart.position(degrees);
    //Lateral movement pid
    int averagePosition = (rightMotorPosition+ leftMotorPosition)/2;
    //proportinal
    error = averagePosition - desiredValue;
    //derivative
    derivative = error - prevError;
    //Velocity -> position -> absement

    //intergral
    totalError += error;

    double lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    //Turning movement PID

    int turnDifference = rightMotorPosition - leftMotorPosition;
    //int turnDifference = Inertial.rotation(degrees);
    //proportinal
    turnError = turnDifference - desiredTurnValue;
    //derivative
    turnDerivative = turnError - turnPrevError;
    //Velocity -> position -> absement

    //intergral
    turnTotalError += turnError;

    double turnMotorPower = turnError * turnkP + turnDerivative * turnkD + turnTotalError * turnkI;

    //
    LeftDriveSmart.spin(vex::forward,lateralMotorPower + turnMotorPower,volt);
    RightDriveSmart.spin(vex::forward,lateralMotorPower + turnMotorPower,volt);
    prevError = error;
    turnPrevError = turnError;
    vex::task::sleep(20);
  }
return 1;
}
bool fliper = false;
bool running = false;
bool sitting = false;
bool mogo2 = false;
int motorTemp1 = leftMotorA.temperature(celsius);
int motorTemp2 = leftMotorB.temperature(celsius);
int motorTemp3 = leftMotorC.temperature(celsius);
int motorTemp4 = rightMotorA.temperature(celsius);
int motorTemp5 = rightMotorB.temperature(celsius);
int motorTemp6 = rightMotorC.temperature(celsius);
int spinnyTemp =  spinny.temperature(celsius);
int spinny2Temp =  spinny2.temperature(celsius);
int avg = motorTemp1 +motorTemp2 + motorTemp3 + motorTemp4+motorTemp5+ motorTemp6;
//INTAKE
void fullintake(){
  running = !running;
  if(running){
    sitting = false;
    spinny.setVelocity(70,percent);
    spinny2.setVelocity(70,percent);
    spinny.spin(vex::forward);
    spinny2.spin(reverse);
  }
  else{
    sitting = false;
    spinny.stop();
    spinny2.stop();
  }
  
}
//REVERSE
void reverse2(){
  sitting = !sitting;
  if(sitting){
    running = false;
    spinny.setVelocity(70,percent);
    spinny2.setVelocity(70,percent);
    spinny.spin(reverse);
    spinny2.spin(vex::forward);
  }
  else{
    running = false;
    spinny.stop();
    spinny2.stop();
  }
}
  
//MOGO
  void mogo3(){
  mogo2 = !mogo2;
  if (mogo2){
  mogo.set(false);
  }
  else{
    mogo.set(true);
  }
  
}
//FLIPPY
void flippy(){
  fliper= !fliper;
  if (fliper){
    flip.set(true);
  }
  else{
    flip.set(false); 

  }

}
void tempDisplay(){
    Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
while(1){

  motorTemp1 = leftMotorA.temperature(celsius);
  motorTemp2 = leftMotorB.temperature(celsius);
  motorTemp3 = leftMotorC.temperature(celsius);
  motorTemp4 = rightMotorA.temperature(celsius);
  motorTemp5 = rightMotorB.temperature(celsius);
  motorTemp6 = rightMotorC.temperature(celsius);
  spinnyTemp =  spinny.temperature(celsius);
  spinny2Temp =  spinny2.temperature(celsius);
  vex::task::sleep(1000);
  avg = motorTemp1 +motorTemp2 + motorTemp3 + motorTemp4+motorTemp5+ motorTemp6;
  //Controller1.Screen.print("Drive Avg " [avg]);
  Controller1.Screen.clearLine();
   std::stringstream ss;
   ss<<"Motor1 Avg "<<spinnyTemp;
   std::string formattedString = ss.str();
  Controller1.Screen.print(formattedString.c_str());
  //Controller1.Screen.print("Drive Avg " [spinny2Temp]);
  if(spinnyTemp>40){
    Controller1.rumble("..--");
  }
}
}

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {

  vex :: task cheese(drivePID);
  resetDriveSensors = true;
  desiredValue = 300;
  desiredTurnValue = 2;
  vex::task::sleep(1000);
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  pidEnable = false;
  // User control code here, inside the loop
  while (1) {
  //MAIN
  Drivetrain.setDriveVelocity(100, percent);
  spinny.setVelocity(100, percent);
  spinny2.setVelocity(100, percent);
  mogo.set(false);
  Controller1.ButtonR1.pressed(fullintake);
  Controller1.ButtonR2.pressed(reverse2);
  Controller1.ButtonL1.pressed(mogo3);
  Controller1.ButtonUp.pressed(flippy);
  tempDisplay();

   // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.drivercontrol(usercontrol);

  //Skills auton
  //Competiton.autonomous(auton);

  //RED SIDE
  //Competiton.autonomous(awp1Red);
  //Competiton.autonomous(awp2Red);

  //BLUE SIDE
  //Competiton.autonomous(awp1Blue);
  //Competiton.autonomous(awp2Blue);
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();


  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
